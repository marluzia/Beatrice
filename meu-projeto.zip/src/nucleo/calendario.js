/**
 * Datas do fechamento, em texto ISO curto ("2026-08-09").
 *
 * Texto e não Date de propósito. Dia é um rótulo do calendário, não um
 * instante: comparar, ordenar e salvar em texto elimina fuso horário e
 * horário de verão do caminho, e a ordem lexicográfica do ISO já é a ordem
 * cronológica. As únicas contas que precisam de Date são as que atravessam
 * meses, e essas passam por UTC.
 *
 * Convenção da janela: `de` entra, `ate` não. A fatura lê no dia 09/03 e de
 * novo no dia 09/04, e cobra 31 dias — o dia da leitura seguinte já pertence
 * ao ciclo seguinte.
 */

const doisDigitos = (n) => String(n).padStart(2, "0");

/** Ano, mês (1-12) e dia -> "AAAA-MM-DD". */
export const diaISO = (ano, mes, dia) => `${ano}-${doisDigitos(mes)}-${doisDigitos(dia)}`;

/** "AAAA-MM-DD" -> { ano, mes, dia }. Devolve null se não for uma data. */
export function partesDoDia(iso) {
  if (typeof iso !== "string") return null;
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(iso.trim());
  if (!m) return null;
  const [ano, mes, dia] = [Number(m[1]), Number(m[2]), Number(m[3])];
  if (mes < 1 || mes > 12 || dia < 1 || dia > diasDoMes(mes, ano)) return null;
  return { ano, mes, dia };
}

/** Quantos dias tem o mês. Fevereiro bissexto sai certo. */
export const diasDoMes = (mes, ano) => new Date(Date.UTC(ano, mes, 0)).getUTCDate();

/** Dia da semana do primeiro do mês, 0 = domingo. */
export const diaDaSemanaInicial = (mes, ano) => new Date(Date.UTC(ano, mes - 1, 1)).getUTCDay();

/** Distância em dias entre dois ISO. Negativa se o segundo vier antes. */
export function distanciaEmDias(deISO, ateISO) {
  const a = partesDoDia(deISO);
  const b = partesDoDia(ateISO);
  if (!a || !b) return 0;
  const ms = Date.UTC(b.ano, b.mes - 1, b.dia) - Date.UTC(a.ano, a.mes - 1, a.dia);
  return Math.round(ms / 86400000);
}

/** Soma dias a um ISO. */
export function somarDias(iso, quantos) {
  const p = partesDoDia(iso);
  if (!p) return iso;
  const d = new Date(Date.UTC(p.ano, p.mes - 1, p.dia + quantos));
  return diaISO(d.getUTCFullYear(), d.getUTCMonth() + 1, d.getUTCDate());
}

export const mesSeguinte = ({ mes, ano }) => (mes === 12 ? { mes: 1, ano: ano + 1 } : { mes: mes + 1, ano });

export const mesAnterior = ({ mes, ano }) => (mes === 1 ? { mes: 12, ano: ano - 1 } : { mes: mes - 1, ano });

/** A janela do próprio mês de referência: do dia 1º ao 1º do mês seguinte. */
export function janelaDoMes(periodo) {
  const proximo = mesSeguinte(periodo);
  return {
    de: diaISO(periodo.ano, periodo.mes, 1),
    ate: diaISO(proximo.ano, proximo.mes, 1),
  };
}

/** A janela está completa e na ordem certa? */
export function janelaValida(janela) {
  if (!janela) return false;
  if (!partesDoDia(janela.de) || !partesDoDia(janela.ate)) return false;
  return janela.de < janela.ate;
}

/**
 * Tamanho da janela em dias. Sem janela válida, cai para o mês de referência.
 *
 * Sem teto de propósito. Havia um de 90 dias aqui, pensado como proteção, e
 * ele fazia o contrário: uma digitação de 519 dias aparecia na tela como
 * "90 dias", plausível o bastante para ninguém desconfiar. Quem julga se o
 * ciclo faz sentido é `cicloValido`, e um ciclo absurdo é recusado, não
 * aparado.
 */
export function diasDaJanela(janela, periodo) {
  if (!janelaValida(janela)) return periodo ? diasDoMes(periodo.mes, periodo.ano) : 0;
  return distanciaEmDias(janela.de, janela.ate);
}

/**
 * Quanto pode durar um ciclo de leitura.
 *
 * Concessionária lê de mês em mês, com folga de alguns dias para feriado e
 * fim de semana: na prática entre 27 e 34. A faixa é mais larga que isso para
 * não recusar fatura real, e estreita o bastante para pegar ano trocado e dia
 * com mês invertido — que é o erro que de fato acontece.
 *
 * Ciclo bimestral, de cidades que faturam água a cada dois meses, cai fora
 * desta faixa. Se aparecer, é aqui que se mexe.
 */
/** A fatura entra neste fechamento? Desligada, não cobra nem exige nada. */
export const faturaAtiva = (fatura) => Boolean(fatura) && fatura.ativa !== false;

export const LIMITES_DO_CICLO = { minimo: 20, maximo: 45 };

/**
 * Primeiro ano que uma fatura de fechamento pode ter.
 *
 * Não existe conta de república para fechar antes disso, e o limite é o que
 * transforma um dedo trocado — 2039, 2932 — em recusa na hora, em vez de num
 * ciclo de séculos que só aparece como problema três telas depois.
 */
export const ANO_MINIMO = 2020;

/**
 * Teto: o ano que vem.
 *
 * A intenção era parar no ano corrente, e ela quebra todo mês de dezembro: um
 * ciclo lido em 28/12 termina em 26/01 do ano seguinte, e é uma fatura
 * perfeitamente comum. O ano a mais ainda recusa 2039 e 2932, que são os
 * dedos trocados que de fato acontecem, e não recusa dezembro.
 */
export const anoMaximo = (hoje = new Date()) => hoje.getFullYear() + 1;

/** A data existe no calendário e cabe na faixa de um fechamento real? */
export function dataPlausivel(iso, hoje) {
  const p = partesDoDia(iso);
  if (!p) return false;
  return p.ano >= ANO_MINIMO && p.ano <= anoMaximo(hoje);
}

/** A janela é um ciclo de fatura plausível? */
export function cicloValido(janela, hoje) {
  if (!janelaValida(janela)) return false;
  if (!dataPlausivel(janela.de, hoje) || !dataPlausivel(janela.ate, hoje)) return false;
  const dias = distanciaEmDias(janela.de, janela.ate);
  return dias >= LIMITES_DO_CICLO.minimo && dias <= LIMITES_DO_CICLO.maximo;
}

/**
 * A fatura está em condições de sair da tela de contas?
 *
 * Três situações, e só a do meio é problema:
 *
 *   em branco      → vale o mês de referência, e está tudo bem
 *   ciclo completo → vale o ciclo
 *   pela metade    → nem uma coisa nem outra
 *
 * Deixar passar meia data era o que produzia fechamento sem mês e contagem de
 * dias que ninguém sabia de onde vinha. Fatura desligada não precisa de nada.
 */
export function faturaPronta(fatura, hoje) {
  if (!faturaAtiva(fatura)) return true;
  const janela = fatura?.janela;
  const temDe = Boolean(janela?.de);
  const temAte = Boolean(janela?.ate);
  if (!temDe && !temAte) return true;
  return cicloValido(janela, hoje);
}

/** O que falta para a fatura ficar pronta, em texto para a tela. */
export function faltaNaFatura(fatura, nome, hoje) {
  if (faturaPronta(fatura, hoje)) return null;

  const janela = fatura?.janela ?? {};
  if (!janela.de || !janela.ate) {
    return `Falta a data ${janela.de ? "final" : "inicial"} do ciclo da ${nome}.`;
  }
  if (janela.de >= janela.ate) {
    return `Na ${nome}, a leitura final precisa vir depois da inicial.`;
  }
  if (!dataPlausivel(janela.de, hoje) || !dataPlausivel(janela.ate, hoje)) {
    return `As datas da ${nome} precisam ser de ${ANO_MINIMO} até ${anoMaximo(hoje)}.`;
  }

  const dias = distanciaEmDias(janela.de, janela.ate);
  return `O ciclo da ${nome} deu ${dias} dias. Uma leitura de fatura fica entre ${LIMITES_DO_CICLO.minimo} e ${LIMITES_DO_CICLO.maximo}.`;
}

/** Tudo o que impede o fechamento de seguir para os outros passos. */
export function faltasDoFechamento(faturas, hoje) {
  return [
    faltaNaFatura(faturas?.luz, "luz", hoje),
    faltaNaFatura(faturas?.agua, "água", hoje),
  ].filter(Boolean);
}

export const fechamentoPronto = (faturas, hoje) => faltasDoFechamento(faturas, hoje).length === 0;

/** A janela está preenchida por inteiro, mesmo que não sirva como ciclo? */
export const janelaPreenchida = (janela) => Boolean(janela?.de) && Boolean(janela?.ate);

/** O dia cai dentro da janela? `de` entra, `ate` não. */
export function dentroDaJanela(iso, janela) {
  if (!janelaValida(janela) || !partesDoDia(iso)) return false;
  return iso >= janela.de && iso < janela.ate;
}

/** Quantos dias da lista caem dentro da janela. Repetidos contam uma vez. */
export function diasNaJanela(dias, janela) {
  if (!Array.isArray(dias)) return 0;
  const vistos = new Set();
  for (const dia of dias) {
    if (!vistos.has(dia) && dentroDaJanela(dia, janela)) vistos.add(dia);
  }
  return vistos.size;
}

/** Todos os dias de `de` até `ate`, inclusive nas duas pontas. */
export function diasEntre(deISO, ateISO) {
  if (!partesDoDia(deISO) || !partesDoDia(ateISO)) return [];
  if (ateISO < deISO) return diasEntre(ateISO, deISO);

  const quantos = Math.min(90, distanciaEmDias(deISO, ateISO));
  return Array.from({ length: quantos + 1 }, (_, i) => somarDias(deISO, i));
}

/**
 * Agrupa dias soltos em trechos corridos.
 *
 * Uma viagem é marcada dia a dia mas lida como período: mostrar
 * "12/09 a 16/09" em vez de cinco etiquetas é o que faz a lista caber na tela
 * e o que permite apagar a viagem inteira de uma vez.
 */
export function intervalosDe(dias) {
  const limpos = [...new Set((dias ?? []).filter((d) => partesDoDia(d)))].sort();
  const trechos = [];

  for (const dia of limpos) {
    const ultimo = trechos[trechos.length - 1];
    if (ultimo && somarDias(ultimo.ate, 1) === dia) ultimo.ate = dia;
    else trechos.push({ de: dia, ate: dia });
  }

  return trechos;
}

/** Último dia do mês, para limitar o seletor nativo. */
export const fimDoMes = ({ mes, ano }) => diaISO(ano, mes, diasDoMes(mes, ano));

/**
 * As semanas do mês para a grade do calendário. Cada semana tem sete
 * posições, começando no domingo; as posições fora do mês vêm como null.
 */
export function semanasDoMes(mes, ano) {
  const total = diasDoMes(mes, ano);
  const celulas = Array.from({ length: diaDaSemanaInicial(mes, ano) }, () => null);

  for (let dia = 1; dia <= total; dia++) celulas.push(diaISO(ano, mes, dia));
  while (celulas.length % 7 !== 0) celulas.push(null);

  const semanas = [];
  for (let i = 0; i < celulas.length; i += 7) semanas.push(celulas.slice(i, i + 7));
  return semanas;
}

export const NOMES_CURTOS_DOS_DIAS = ["D", "S", "T", "Q", "Q", "S", "S"];

/**
 * O mês de referência do fechamento, deduzido do começo do ciclo.
 *
 * O mês deixou de ser escolhido à mão: quem o define é a primeira data de
 * leitura. A luz manda, e a água só entra se a luz ainda não tiver data —
 * senão o rótulo do fechamento ficaria trocando conforme a ordem em que as
 * duas faturas fossem preenchidas.
 */
/**
 * O mês em que a maior parte do ciclo caiu.
 *
 * Não é o mês do começo: uma leitura de 28/04 a 26/05 tem três dias em abril
 * e vinte e cinco em maio, e a fatura se chama de maio. Também não é o do
 * fim, que erraria o caso espelhado. O mês que domina o período é o que a
 * fatura chama de referência.
 */
export function mesPredominante(janela) {
  if (!cicloValido(janela)) return null;

  const dias = {};
  const total = distanciaEmDias(janela.de, janela.ate);

  for (let i = 0; i < total; i++) {
    const p = partesDoDia(somarDias(janela.de, i));
    if (!p) continue;
    const chave = `${p.ano}-${p.mes}`;
    dias[chave] = (dias[chave] ?? 0) + 1;
  }

  const vencedor = Object.entries(dias).sort((a, b) => b[1] - a[1])[0];
  if (!vencedor) return null;

  const [ano, mes] = vencedor[0].split("-").map(Number);
  return { mes, ano };
}

/**
 * O mês do fechamento sai do ciclo de leitura, e só de um ciclo completo:
 * enquanto a pessoa está digitando a segunda data, o rótulo não pode ficar
 * pulando de mês a cada tecla.
 */
export function periodoDasFaturas(faturas, padrao) {
  return (
    mesPredominante(faturas?.luz?.janela) ?? mesPredominante(faturas?.agua?.janela) ?? padrao
  );
}

/**
 * A janela do fechamento: o período que o rateio cobre.
 *
 * É o ciclo da luz, e não o mês do calendário. Depois que as datas de leitura
 * passaram a ser digitadas, o mês virou só um rótulo — insistir nele faria a
 * pessoa marcar cinco dias de viagem e ver "31 dias contados", porque a
 * viagem caiu em setembro e o rótulo dizia agosto.
 *
 * A água entra só se a luz não tiver ciclo, pela mesma razão de o rótulo do
 * mês seguir a luz: senão o fechamento mudaria de tamanho conforme a ordem em
 * que as duas faturas fossem preenchidas.
 */

export function janelaDoFechamento(faturas, periodo) {
  const luz = faturas?.luz;
  const agua = faturas?.agua;
  if (faturaAtiva(luz) && cicloValido(luz.janela)) return luz.janela;
  if (faturaAtiva(agua) && cicloValido(agua.janela)) return agua.janela;
  return janelaDoMes(periodo);
}

/**
 * O trecho que pode ser marcado: do começo do ciclo mais cedo ao fim do ciclo
 * mais tarde.
 *
 * Dia fora dessa faixa não entra em fatura nenhuma — marcá-lo não desconta
 * nada de ninguém. Em vez de aceitar o clique e ignorar em silêncio, o
 * calendário desliga o dia.
 */
export function janelaTotal(faturas, periodo) {
  const janelas = [faturas?.luz, faturas?.agua]
    .filter(faturaAtiva)
    .map((f) => f.janela)
    .filter((j) => cicloValido(j));
  if (janelas.length === 0) return janelaDoMes(periodo);

  return {
    de: janelas.map((j) => j.de).sort()[0],
    ate: janelas.map((j) => j.ate).sort().pop(),
  };
}

/** Último dia que ainda conta: a janela termina antes de `ate`. */
export const ultimoDiaDaJanela = (janela) => somarDias(janela.ate, -1);

/** "2026-08" — para comparar em que mês um dia cai. */
export const mesDoDia = (iso) => (iso ?? "").slice(0, 7);

export const chaveDoMes = ({ mes, ano }) => `${ano}-${String(mes).padStart(2, "0")}`;

/**
 * O trecho coberto pelas duas faturas ao mesmo tempo.
 *
 * Fora dele, um uso cai no ciclo de uma conta e não no da outra — e é por
 * isso que informar só o total de usos, sem data, deixa de ser exato quando
 * as duas leituras não coincidem.
 */
export function janelaComum(faturas, periodo) {
  const janelas = [faturas?.luz, faturas?.agua]
    .filter(faturaAtiva)
    .map((f) => f.janela)
    .filter((j) => cicloValido(j));

  if (janelas.length < 2) return janelaTotal(faturas, periodo);

  const de = janelas.map((j) => j.de).sort().pop();
  const ate = janelas.map((j) => j.ate).sort()[0];
  return de < ate ? { de, ate } : null;
}

/** Dias que uma fatura cobre e a outra não. Zero quando os ciclos coincidem. */
export function diasSemSobreposicao(faturas, periodo) {
  const total = janelaTotal(faturas, periodo);
  const comum = janelaComum(faturas, periodo);
  return diasDaJanela(total, periodo) - (comum ? diasDaJanela(comum, periodo) : 0);
}

/**
 * Existe alguma conta com o ciclo escrito, porém impossível?
 *
 * É o que separa "ainda não preencheu" de "preencheu errado". No primeiro
 * caso vale o mês corrente; no segundo, o fechamento não tem mês — dizer
 * "agosto" para um ciclo de 519 dias seria inventar.
 */
export function temCicloInvalido(faturas) {
  return [faturas?.luz, faturas?.agua]
    .filter(faturaAtiva)
    .some((f) => janelaPreenchida(f.janela) && !cicloValido(f.janela));
}
