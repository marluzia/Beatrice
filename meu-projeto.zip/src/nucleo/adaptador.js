import {
  calcular as calcularNoMotor,
  rateiosPermitidos,
  diasDoPeriodo,
  consumoDeclaradoPorHora,
} from "./motor.ts";
import { nomeOu, num } from "./formato.js";
import {
  dentroDaJanela,
  diasDaJanela,
  diasNaJanela,
  cicloValido,
  faturaAtiva,
  janelaDoFechamento,
  janelaDoMes,
  janelaValida,
} from "./calendario.js";


/**
 * Usos datados: eventos.
 *
 * O dia não serve de unidade. Uma pessoa pode lavar duas vezes no mesmo dia,
 * e uma lavagem pode ser de duas pessoas — coisas que uma lista de dias não
 * consegue dizer. O evento carrega data, quantidade e quem participou, e a
 * quantidade se reparte igualmente entre os participantes.
 *
 * Quem não datou nada continua com o total por pessoa, que resolve a maioria
 * das casas. A data só passa a importar quando o ciclo de uma fatura não
 * cobre o dia do uso.
 */
export const eventosDe = (item) => (Array.isArray(item.eventos) ? item.eventos : []);

export const temUsoDatado = (item) => eventosDe(item).length > 0;

/** Quanto do evento cabe a uma pessoa. Sem participante, não cabe a ninguém. */
export function parteNoEvento(evento, id) {
  const participantes = evento?.participantes ?? [];
  if (!participantes.includes(id)) return 0;

  const quantidade = num(evento.quantidade);
  return (quantidade > 0 ? quantidade : 1) / participantes.length;
}

const usosDe = (item, id) => {
  const eventos = eventosDe(item);
  if (eventos.length === 0) return num(item.usosPorPessoa?.[id]);
  return eventos.reduce((soma, e) => soma + parteNoEvento(e, id), 0);
};

const usosPorJanela = (item, janela) =>
  Object.fromEntries(
    (item.participantes ?? []).map((id) => {
      const eventos = eventosDe(item);
      // Sem data, o uso entra nas duas faturas: é o que a pessoa afirmou.
      if (eventos.length === 0) return [id, num(item.usosPorPessoa?.[id])];

      const dentro = eventos
        .filter((e) => dentroDaJanela(e.data, janela))
        .reduce((soma, e) => soma + parteNoEvento(e, id), 0);
      return [id, dentro];
    }),
  );

/**
 * Usos que uma das faturas não cobre.
 *
 * Uma ocorrência por fatura descoberta, não por evento: com ciclos que não se
 * encostam, o mesmo dia pode ficar fora das duas, e registrar só a primeira
 * fazia a outra sumir calada.
 *
 * `quando` é relativo à fatura que faltou. Antes do começo daquele ciclo, o
 * consumo entrou na fatura anterior e aquela conta já fechou. Depois do fim,
 * virá na próxima — e essa precisa ser remarcada no fechamento seguinte.
 */
export function orfasDoItem(item, faturas, periodo) {
  if (item.especie !== "porUso" || item.origemUso !== "fatura") return [];

  /**
   * Só as faturas que estão no fechamento.
   *
   * Fatura desligada não cobra nada, então não há uso "fora do ciclo dela" —
   * e o aviso que dizia "a água desse dia vem na próxima fatura" continuava
   * na tela depois de a água ser desligada, falando de uma conta que não
   * existe mais neste fechamento.
   */
  const ciclos = [
    ["luz", faturas.luz],
    ["agua", faturas.agua],
  ]
    .filter(([, fatura]) => faturaAtiva(fatura))
    .map(([qual, fatura]) => [qual, janelaDaFatura(fatura, periodo)]);

  const achados = [];

  for (const evento of eventosDe(item)) {
    for (const [qual, janela] of ciclos) {
      if (dentroDaJanela(evento.data, janela)) continue;

      achados.push({
        itemId: item.id,
        item: item.nome,
        eventoId: evento.id,
        dia: evento.data,
        quantidade: num(evento.quantidade) || 1,
        participantes: evento.participantes ?? [],
        faltando: qual,
        quando: evento.data < janela.de ? "passado" : "futuro",
      });
    }
  }

  return achados.sort((a, b) => String(a.dia).localeCompare(String(b.dia)));
}

export const lavagensForaDoCiclo = (estado) =>
  estado.itens.flatMap((item) => orfasDoItem(item, estado.faturas, estado.periodo));

/** Item da tela - Item do motor. */
/**
 * A unidade é do aparelho, não do fechamento.
 *
 * Antes ela era forçada para a fatura ativa, e um item de 7 m³ virava 7 kWh
 * quando a água era desligada — o número digitado passava a significar outra
 * coisa sem ninguém tocar nele. Agora o item cuja conta saiu do fechamento
 * é travado por `faltaParaItem`, que diz o que falta em vez de reinterpretar.
 */
export const unidadeDoItem = (item) => item.unidade;

/**
 * O que falta em Contas para este item poder ser calculado.
 *
 * Um aparelho medido em kWh precisa da fatura de luz com consumo e valores:
 * sem isso a tarifa é zero e o item entra na conta valendo nada, calado. É
 * melhor dizer o que falta do que cobrar R$ 0,00 sem explicação.
 */
export function faltaParaItem(item, faturas) {
  const precisa = new Set();

  if (item.especie === "consumo" || item.especie === "porHora") {
    precisa.add(item.unidade);
  }
  if (item.especie === "porUso" && item.origemUso === "fatura") {
    if (faturaAtiva(faturas?.luz)) precisa.add("kwh");
    if (faturaAtiva(faturas?.agua)) precisa.add("m3");
    if (precisa.size === 0) precisa.add("kwh");
  }

  const faltando = [];

  for (const unidade of precisa) {
    const qual = unidade === "kwh" ? "luz" : "agua";
    const nome = unidade === "kwh" ? "luz" : "água";
    const fatura = faturas?.[qual];

    if (!faturaAtiva(fatura)) {
      faltando.push(`a conta de ${nome} não está neste fechamento`);
      continue;
    }
    if (consumoDaFatura(fatura) <= 0) {
      faltando.push(`o consumo da ${nome}, em ${unidade === "kwh" ? "kWh" : "m³"}`);
    }
    if (valorDoConsumo(fatura) === 0) {
      faltando.push(`as linhas de consumo da fatura de ${nome}`);
    }
  }

  return faltando;
}

export function itemParaMotor(item, janelas, faturas) {
  const custo =
    item.especie === "consumo"
      ? { tipo: "consumo", quantidade: num(item.quantidade), unidade: item.unidade }
      : item.especie === "porHora"
      ? {
          tipo: "porHora",
          porHora: num(item.porHora),
          horas: num(item.horas),
          unidade: item.unidade,
        }
      : item.especie === "porUso"
        ? {
            tipo: "porUso",
            usosTotais: num(item.usos),
            unitario:
              item.origemUso === "reais"
                ? { origem: "reais", valorPorUso: num(item.valorPorUso) }
                : {
                    origem: "fatura",
                    kwhPorUso: num(item.kwhPorUso),
                    m3PorUso: num(item.m3PorUso),
                  },
          }
        : { tipo: "reais", valor: num(item.valor) };

  const rateio =
    item.rateio === "uso"
      ? {
          tipo: "uso",
          usos: Object.fromEntries(
            (item.participantes ?? []).map((id) => [id, usosDe(item, id)]),
          ),
          ...(temUsoDatado(item) && janelas
            ? {
                usosLuz: usosPorJanela(item, janelas.luz),
                usosAgua: usosPorJanela(item, janelas.agua),
              }
            : {}),
        }
      : { tipo: item.rateio };

  return {
    id: item.id,
    nome: item.nome?.trim() || "Item sem nome",
    custo,
    participantes: item.participantes ?? [],
    rateio,
    rateiosDoItem: item.rateios,
  };
}

/** Estado da tela - Estado do motor. */
/**
 * As duas classes da partição. Linha zerada não entra em nenhuma: campo em
 * branco no formulário não pode virar item de R$ 0,00 no resultado.
 *
 * Valor negativo entra normalmente — crédito de geração distribuída, bônus e
 * restituição aparecem na fatura como abatimento, e ignorá-los cobraria da
 * casa dinheiro que a distribuidora devolveu.
 */
export function linhasPorComportamento(fatura, comportamento) {
  return (fatura?.linhas ?? []).filter(
    (l) => l.comportamento === comportamento && num(l.valor) !== 0,
  );
}

/** Soma das linhas que acompanham o consumo. É o que forma a tarifa. */
/**
 * Dinheiro que acompanha o consumo, incluindo os abatimentos.
 *
 * Um crédito de energia compensada é uma linha que anda com o consumo — só
 * que para baixo. Ele entra aqui pelo valor negativo, mas a quantidade dele
 * não entra no consumo medido: é a mesma energia da linha que ele abate, e
 * contá-la duas vezes derrubaria a tarifa pela metade.
 */
export function valorDoConsumo(fatura) {
  const linhas = fatura?.linhas ?? [];
  return linhas
    .filter((l) => l.comportamento === "consumo" || l.comportamento === "abatimento")
    .reduce((s, l) => s + num(l.valor), 0);
}

/** Quantidade somada das linhas que representam consumo de verdade. */
export function consumoMedido(fatura) {
  return linhasPorComportamento(fatura, "consumo").reduce((s, l) => s + num(l.quantidade), 0);
}

/**
 * O consumo da fatura é a soma das quantidades das linhas de consumo.
 *
 * Havia um campo à parte para digitar o total, usado quando as linhas ainda
 * não tinham quantidade. Duas fontes para o mesmo número acabam divergindo, e
 * a que a pessoa não está olhando é a que fica errada. A fatura já traz a
 * quantidade linha a linha; somar é o que ela mesma faz no rodapé.
 */
export function consumoDaFatura(fatura) {
  return consumoMedido(fatura);
}

/** Soma das linhas que dividem igual. */
export function totalDasTaxas(fatura) {
  return linhasPorComportamento(fatura, "igual").reduce((s, l) => s + num(l.valor), 0);
}

/** Total da fatura: as duas classes somadas. É o número a conferir com o papel. */
export function totalDaFatura(fatura) {
  return valorDoConsumo(fatura) + totalDasTaxas(fatura);
}

/**
 * Tarifa deduzida das linhas de consumo.
 *
 * Serve de conferência: a fatura de luz imprime o preço por kWh, e se o número
 * daqui não bater com o de lá, alguma linha ficou de fora.
 */
export function tarifaDaFatura(fatura) {
  const quantidade = consumoDaFatura(fatura);
  return quantidade > 0 ? valorDoConsumo(fatura) / quantidade : 0;
}

function faturaParaMotor(fatura, qual) {
  // Fatura desligada não tem consumo nem taxa: a casa não a recebeu ainda.
  if (!faturaAtiva(fatura)) {
    return qual === "luz"
      ? { luzKwh: 0, luzValor: 0, luzTaxas: [] }
      : { aguaM3: 0, aguaValor: 0, aguaTaxas: [] };
  }

  const consumo = consumoDaFatura(fatura);
  const taxas = linhasPorComportamento(fatura, "igual").map((l) => ({
    nome: l.nome ?? "",
    valor: num(l.valor),
  }));

  const total = totalDaFatura(fatura);

  return qual === "luz"
    ? { luzKwh: consumo, luzValor: total, luzTaxas: taxas }
    : { aguaM3: consumo, aguaValor: total, aguaTaxas: taxas };
}

/**
 * Ausência de um morador dentro de uma janela.
 *
 * Quem marcou dias no calendário tem a lista; quem vem de um estado antigo,
 * salvo antes do calendário existir, tem só o número. Nesse caso o número vale
 * para todas as janelas, que é exatamente o que o CDR fazia antes.
 */
export function diasForaNaJanela(morador, janela) {
  if (Array.isArray(morador.ausencias)) return diasNaJanela(morador.ausencias, janela);
  return num(morador.diasFora);
}

/** A janela de uma fatura, ou a do mês de referência quando não foi marcada. */
export const janelaDaFatura = (fatura, periodo) =>
  cicloValido(fatura?.janela) ? fatura.janela : janelaDoMes(periodo);

export function paraMotor(estado) {
  const { periodo } = estado;
  const doFechamento = janelaDoFechamento(estado.faturas, periodo);
  const daLuz = janelaDaFatura(estado.faturas.luz, periodo);
  const daAgua = janelaDaFatura(estado.faturas.agua, periodo);

  return {
    periodo: {
      ...periodo,
      // O que não é kWh nem m³ — gás, internet, faxina — segue o fechamento.
      dias: diasDaJanela(doFechamento, periodo),
      diasLuz: diasDaJanela(daLuz, periodo),
      diasAgua: diasDaJanela(daAgua, periodo),
    },
    faturas: {
      ...faturaParaMotor(estado.faturas.luz, "luz"),
      ...faturaParaMotor(estado.faturas.agua, "agua"),
    },
    moradores: estado.moradores.map((m) => ({
      id: m.id,
      nome: m.nome,
      diasFora: diasForaNaJanela(m, doFechamento),
      diasForaLuz: diasForaNaJanela(m, daLuz),
      diasForaAgua: diasForaNaJanela(m, daAgua),
    })),
    itens: estado.itens.map((i) => itemParaMotor(i, { luz: daLuz, agua: daAgua }, estado.faturas)),
  };
}

/** Roda o motor sobre o estado da tela. */
/**
 * O alerta das lavagens órfãs nasce aqui, e não no motor, porque o motor não
 * conhece datas — ele recebe contagens já resolvidas por janela.
 */
function alertaDeLavagens(estado) {
  const foras = lavagensForaDoCiclo(estado);
  if (foras.length === 0) return [];

  const nome = (id) => {
    const i = estado.moradores.findIndex((m) => m.id === id);
    return i < 0 ? "alguém" : nomeOu(estado.moradores[i].nome, i);
  };
  const curto = (d) => `${d.slice(8, 10)}/${d.slice(5, 7)}`;

  const futuras = foras.filter((f) => f.quando === "futuro");
  const passadas = foras.filter((f) => f.quando === "passado");
  const alertas = [];

  if (futuras.length > 0) {
    const quais = futuras
      .map((f) => `${nome(f.moradorId)} em ${curto(f.dia)} (${f.faltando === "luz" ? "luz" : "água"})`)
      .join("; ");
    alertas.push({
      nivel: "aviso",
      texto: `Estas lavagens caíram depois do fim de um dos ciclos: ${quais}. Essa parte vem na próxima fatura, então não está cobrada aqui. Marque os mesmos dias no fechamento do mês que vem.`,
    });
  }

  if (passadas.length > 0) {
    const quais = passadas
      .map((f) => `${nome(f.moradorId)} em ${curto(f.dia)} (${f.faltando === "luz" ? "luz" : "água"})`)
      .join("; ");
    alertas.push({
      nivel: "aviso",
      texto: `Estas lavagens aconteceram antes de um dos ciclos começar: ${quais}. Essa parte entrou na fatura anterior, que já foi fechada — aqui ela não é cobrada de novo.`,
    });
  }

  return alertas;
}

export const calcular = (estado) => {
  const resultado = calcularNoMotor(paraMotor(estado));
  const extras = alertaDeLavagens(estado);
  return extras.length ? { ...resultado, alertas: [...resultado.alertas, ...extras] } : resultado;
};

/** Divisões que fazem sentido para este item, segundo o próprio motor. */
export const rateiosDoItem = (item) => rateiosPermitidos(itemParaMotor(item));

/** Dias contados de um morador, para mostrar enquanto a pessoa digita. */
/** Dias que uma pessoa pesa numa fatura: o ciclo dela menos as ausências. */
export function diasContadosNaFatura(morador, fatura, periodo) {
  const janela = janelaDaFatura(fatura, periodo);
  const dias = diasDaJanela(janela, periodo);
  return Math.max(0, Math.min(dias, dias - diasForaNaJanela(morador, janela)));
}

export function diasContadosDe(morador, periodo, faturas) {
  const janela = faturas ? janelaDoFechamento(faturas, periodo) : janelaDoMes(periodo);
  const dias = diasDaJanela(janela, periodo);
  return Math.max(0, Math.min(dias, dias - diasForaNaJanela(morador, janela)));
}

/**
 * Total consumido por um aparelho declarado por hora, para a tela mostrar
 * enquanto a pessoa digita. Passa pelo motor para não existirem duas contas.
 */
export const totalDeclaradoPorHora = (item) =>
  consumoDeclaradoPorHora({ porHora: num(item.porHora), horas: num(item.horas) });

export { diasDoPeriodo };
