import { novoId } from "./formato.js";
import { criarItem, modeloPorChave } from "./catalogo.js";

// Itens que quase toda república tem, para a tela não abrir vazia. 
const ITENS_DE_PARTIDA = ["faxina", "geladeira", "maquina", "gas", "internet"];

export function novaLinha(nome = "", comportamento = "consumo") {
  // A quantidade mora na linha, e não num campo solto, porque uma fatura com
  // geração distribuída imprime três quantidades diferentes e só a soma de
  // duas é o consumo real do medidor.
  return { id: novoId("l"), nome, quantidade: "", valor: "", comportamento };
}

export function faturaVazia(unidade) {
  const linhas =
    unidade === "kwh"
      ? [novaLinha("Energia elétrica", "consumo"), novaLinha("Iluminação pública", "igual")]
      : [novaLinha("Tarifa água", "consumo")];

  // A quantidade consumida não tem campo próprio: sai da soma das linhas.
  // janela: as duas datas de leitura, marcadas no calendário. Em branco, vale
  // o mês de referência inteiro.
  // ativa: a casa pode fechar o mês com só uma das contas em mãos.
  return { unidade, ativa: true, janela: null, linhas };
}

export function estadoInicial(quantosMoradores = 3) {
  const moradores = Array.from({ length: quantosMoradores }, () => ({
    id: novoId("m"),
    nome: "",
    diasFora: "",
    ausencias: [],
  }));
  const ids = moradores.map((m) => m.id);
  const hoje = new Date();

  return {
    periodo: { mes: hoje.getMonth() + 1, ano: hoje.getFullYear() },
    faturas: {
      luz: faturaVazia("kwh"),
      agua: faturaVazia("m3"),
    },
    moradores,
    itens: ITENS_DE_PARTIDA.map((chave) => criarItem(modeloPorChave(chave), ids)),
  };
}
