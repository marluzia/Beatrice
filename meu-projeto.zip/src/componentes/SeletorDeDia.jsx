import { useState } from "react";
import Botao from "./Botao.jsx";
import Calendario from "./Calendario.jsx";

/**
 * O dia de um uso, marcado no calendário.
 *
 * Mesmo desenho das ausências: um botão que abre a grade, e a data aparecendo
 * como etiqueta depois de marcada. Não há caixa de texto — uma data digitada à
 * mão aqui só teria como validar contra o mesmo calendário que já está a um
 * clique, e o quadrado vazio dizia à pessoa que ela precisava escrever algo.
 *
 * A diferença para as ausências é a quantidade: aqui é um dia por vez. Cada
 * uso aconteceu num dia só, e dois usos em dias diferentes são dois
 * lançamentos.
 */
const diaCurto = (iso) => `${iso.slice(8, 10)}/${iso.slice(5, 7)}/${iso.slice(0, 4)}`;

export default function SeletorDeDia({ valor, aoMudar, periodo, limite, etiqueta }) {
  const [aberto, setAberto] = useState(false);

  const escolher = (dias) => {
    // O calendário é o mesmo das ausências e devolve uma lista. O dia que
    // interessa é o que ainda não estava marcado: foi nele que a pessoa
    // clicou. Clicar de novo no dia já escolhido limpa a marcação.
    const novo = dias.find((d) => d !== valor) ?? null;
    aoMudar(novo);
    if (novo) setAberto(false);
  };

  return (
    <div className="dia-do-uso">
      <Botao
        tipo="fantasma"
        aoClicar={() => setAberto(!aberto)}
        aria-expanded={aberto}
      >
        {aberto ? "Ocultar calendário" : valor ? "Trocar dia" : "Marcar dia"}
      </Botao>

      {valor && !aberto && <span className="dia-do-uso__marca">{diaCurto(valor)}</span>}

      {aberto && (
        <Calendario
          periodo={periodo}
          limite={limite}
          dias={valor ? [valor] : []}
          aoMudar={escolher}
          etiqueta={etiqueta}
        />
      )}
    </div>
  );
}
