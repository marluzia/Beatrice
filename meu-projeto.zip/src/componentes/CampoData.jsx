import { useEffect, useState } from "react";
import { diaISO, partesDoDia } from "../nucleo/calendario.js";

/**
 * Campo de data no formato brasileiro, dia/mês/ano.
 *
 * Não usa `input type="date"` de propósito. O seletor nativo desenha a data
 * conforme o idioma do navegador ou a região do sistema, não conforme a
 * página: num Chrome em inglês sai mm/dd/aaaa, e não existe atributo que
 * force o contrário. Aqui o formato é sempre dd/mm/aaaa.
 *
 * Por dentro continua tudo em ISO — o que entra e o que sai por `valor` e
 * `aoMudar` é "2026-08-09". A máscara é só a camada de leitura.
 */

const soDigitos = (texto) => texto.replace(/\D/g, "");

/**
 * Só dígitos e separadores.
 *
 * Espaço, ponto e traço viram barra: quem digita "01 09 2026" ou "1-9-2026"
 * está escrevendo a mesma data, e obrigar a barra só cria erro de digitação.
 * Letra some. Separador no começo não separa nada, e repetido conta uma vez.
 */
const limpar = (texto) =>
  String(texto ?? "")
    .replace(/[^\d/\s.-]/g, "")
    .replace(/[\s.-]+/g, "/")
    .replace(/^\/+/, "")
    .replace(/\/{2,}/g, "/");

const doisDigitos = (v) => (v.length === 1 ? `0${v}` : v);

/**
 * Recusa o dígito que tornaria o grupo impossível.
 *
 * Máscara que aceita 34 no dia e 23 no mês adia o erro: a pessoa termina de
 * escrever, vê "23/23/2323" na tela e só descobre o problema quando o
 * fechamento fica sem mês. Barrar na tecla é mais fácil de entender — o campo
 * não avança, e ela reescreve o dígito.
 *
 * `completo` avisa que o grupo terminou mesmo com um dígito só: quem digita 9
 * no dia quer 09, e o próximo dígito já é do mês.
 */
function normalizarGrupo(valor, maximo) {
  const maiorPrimeiro = Math.floor(maximo / 10);

  if (valor.length === 1) {
    return Number(valor) > maiorPrimeiro
      ? { valor: `0${valor}`, completo: true }
      : { valor, completo: false };
  }

  const n = Number(valor);
  if (n < 1 || n > maximo) return { valor: valor.slice(0, -1), recusado: true };
  return { valor, completo: true };
}

/**
 * Separa o texto em dia, mês e ano, consumindo dígito a dígito.
 *
 * Percorrer em vez de fatiar é o que faz "9" virar dia 09 e mandar o próximo
 * dígito para o mês, sem que "98" vire dia 98. A barra digitada à mão encerra
 * o grupo onde estiver.
 */
function separar(limpo) {
  const grupos = ["", "", ""];
  let atual = 0;

  const empurrar = (indice, digito, maximo) => {
    const g = normalizarGrupo(grupos[indice] + digito, maximo);
    if (g.recusado) return;
    grupos[indice] = g.valor;
    if (g.completo) atual = indice + 1;
  };

  for (const c of limpo) {
    if (c === "/") {
      if (atual < 2 && grupos[atual] !== "") atual += 1;
      continue;
    }
    if (atual === 0) empurrar(0, c, 31);
    else if (atual === 1) empurrar(1, c, 12);
    else {
      // O ano começa em 1 ou 2. Não é elegância: é o que impede 4202 de virar
      // data aceita, com ciclo de séculos, sem ninguém notar o dedo trocado.
      if (grupos[2] === "" && !"12".includes(c)) continue;
      if (grupos[2].length < 4) grupos[2] += c;
    }
  }

  return grupos;
}

/** Vai colocando as barras conforme a pessoa digita. */
export function comMascara(bruto) {
  const limpo = limpar(bruto);
  const [dia, mes, ano] = separar(limpo);
  const terminaEmBarra = limpo.endsWith("/");

  if (dia === "") return "";
  if (mes === "") return terminaEmBarra ? `${doisDigitos(dia)}/` : dia;
  if (ano === "") {
    return terminaEmBarra
      ? `${doisDigitos(dia)}/${doisDigitos(mes)}/`
      : `${doisDigitos(dia)}/${mes}`;
  }
  return `${doisDigitos(dia)}/${doisDigitos(mes)}/${ano}`;
}

/**
 * "09/08/2026" -> "2026-08-09". Devolve null enquanto não for uma data real,
 * e é aqui que 31/02 morre.
 *
 * Lê os grupos como estão escritos, sem normalizar. A máscara pode recusar um
 * dígito enquanto a pessoa digita; aqui, não — texto colado de fora ou vindo
 * do armazenamento precisa ser recusado, e não reinterpretado. Normalizar
 * aqui fazia "32/01/2026" virar 03/01/2026 em silêncio: o dia 32 não existia,
 * mas o 3 sozinho existia, e a data saía válida e errada.
 *
 * Exige o ano com quatro dígitos. Aceitar dois era uma gentileza que custava
 * caro: no meio da digitação de 2026, o "20" virava o ano 2020, a data ficava
 * válida e errada, e o tamanho do ciclo pulava a cada tecla.
 */
export function paraISO(texto) {
  const limpo = limpar(texto);
  let dia;
  let mes;
  let ano;

  if (limpo.includes("/")) {
    const partes = limpo.split("/");
    if (partes.length !== 3 || partes.some((p) => p === "")) return null;
    [dia, mes, ano] = partes;
  } else {
    if (limpo.length !== 8) return null;
    [dia, mes, ano] = [limpo.slice(0, 2), limpo.slice(2, 4), limpo.slice(4)];
  }

  if (dia.length > 2 || mes.length > 2 || ano.length !== 4) return null;

  const iso = diaISO(Number(ano), Number(mes), Number(dia));
  return partesDoDia(iso) ? iso : null;
}

const paraBR = (iso) => (iso ? `${iso.slice(8, 10)}/${iso.slice(5, 7)}/${iso.slice(0, 4)}` : "");

export default function CampoData({ valor, aoMudar, aoInvalidar, rotulo, etiqueta }) {
  const [texto, setTexto] = useState(() => paraBR(valor));

  /**
   * Só reescreve o campo quando o valor muda por fora — apagar, carregar do
   * navegador. Sem essa guarda, uma data ainda incompleta ou impossível
   * (31/02) seria apagada no meio da digitação.
   */
  useEffect(() => {
    const atual = paraISO(texto);
    if (atual === valor) return;
    if (!valor && atual === null) return;
    setTexto(paraBR(valor));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [valor]);

  // Só acusa erro depois que a data está escrita por inteiro.
  const invalido = soDigitos(texto).length >= 8 && paraISO(texto) === null;

  const digitar = (bruto) => {
    const visto = comMascara(bruto);
    setTexto(visto);
    aoMudar(paraISO(visto));
    // A borda vermelha some junto com o campo em telas estreitas, e não
    // explica nada. Quem sabe dizer o que houve é o bloco do período.
    aoInvalidar?.(soDigitos(visto).length >= 8 && paraISO(visto) === null);
  };

  return (
    <label className="campo-data">
      {rotulo && <span className="rotulo rotulo-solto">{rotulo}</span>}
      <input
        type="text"
        className={`caixa caixa--data ${invalido ? "caixa--erro" : ""}`}
        value={texto}
        onChange={(e) => digitar(e.target.value)}
        placeholder="dd/mm/aaaa"
        inputMode="numeric"
        autoComplete="off"
        aria-label={etiqueta}
        aria-invalid={invalido || undefined}
      />
    </label>
  );
}
