/**
 * `bloqueadosApos` desliga os passos seguintes ao índice dado. O botão fica
 * visível e apagado: sumir com ele esconderia que existe caminho adiante, e a
 * pessoa não saberia que está presa nem por quê.
 */
export default function Navegacao({ passos, atual, aoEscolher, bloqueadosApos }) {
  return (
    <nav className="passos" aria-label="Etapas">
      {passos.map((p, i) => (
        <button
          key={p}
          type="button"
          className="passo-botao"
          aria-current={i === atual ? "step" : undefined}
          disabled={bloqueadosApos !== undefined && i > bloqueadosApos}
          onClick={() => aoEscolher(i)}
        >
          <span className="ordem">{String(i + 1).padStart(2, "0")}</span>
          {p}
        </button>
      ))}
    </nav>
  );
}
