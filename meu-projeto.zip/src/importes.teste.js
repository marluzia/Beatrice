import { readFileSync, readdirSync } from "node:fs";
import { join } from "node:path";
import { describe, expect, it } from "vitest";

/**
 * Componente usado sem estar importado.
 *
 * Isso não é erro de sintaxe: o arquivo compila, o build passa, e a tela só
 * quebra quando alguém navega até ela — foi assim que o passo de moradores
 * caiu em produção depois de uma troca de importes. Nenhum outro teste pega,
 * porque só o `App.teste.jsx` renderiza componente, e só os quatro passos.
 *
 * A varredura é de texto mesmo. Não entende JavaScript, e não precisa:
 * procura `<Maiuscula` e cobra que o nome exista no arquivo.
 */

function arquivosJsx(pasta) {
  const achados = [];

  for (const item of readdirSync(pasta, { withFileTypes: true })) {
    const caminho = join(pasta, item.name);
    if (item.isDirectory()) achados.push(...arquivosJsx(caminho));
    else if (item.name.endsWith(".jsx")) achados.push(caminho);
  }

  return achados;
}

/** Nomes que aparecem como tag: <Ficha>, <Botao />, <AjudaItens />. */
const usados = (codigo) => new Set([...codigo.matchAll(/<([A-Z][\w]*)/g)].map((m) => m[1]));

/** Nomes que o arquivo tem: importados, declarados ou atribuídos. */
function disponiveis(codigo) {
  const nomes = new Set();

  for (const m of codigo.matchAll(/import\s+(?:([\w]+)\s*,?\s*)?(?:\{([^}]*)\})?\s*from/g)) {
    if (m[1]) nomes.add(m[1]);
    for (const parte of (m[2] ?? "").split(",")) {
      const nome = parte.split(" as ").pop().trim();
      if (nome) nomes.add(nome);
    }
  }

  for (const m of codigo.matchAll(/function\s+([A-Z][\w]*)/g)) nomes.add(m[1]);
  for (const m of codigo.matchAll(/const\s+([A-Z][\w]*)\s*=/g)) nomes.add(m[1]);

  return nomes;
}

describe("componentes usados existem", () => {
  const arquivos = arquivosJsx("src");

  it("encontra a árvore de telas", () => {
    expect(arquivos.length).toBeGreaterThan(10);
  });

  for (const caminho of arquivos) {
    it(`${caminho} importa tudo o que usa`, () => {
      const codigo = readFileSync(caminho, "utf8");
      const tem = disponiveis(codigo);
      const faltando = [...usados(codigo)].filter((nome) => !tem.has(nome));

      expect(faltando, `${caminho} usa <${faltando.join(">, <")}> sem ter o nome`).toEqual([]);
    });
  }
});
